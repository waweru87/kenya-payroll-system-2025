
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import csv
import tempfile
import os
import json
import webbrowser

# ============================
#   KENYA PAYROLL (2025)
#   Multi-Employee GUI App
#   Features:
#   - Payroll No auto-increment; confirmation if edited/overridden; duplicate prevention
#   - Always-visible vertical + horizontal scrollbars on the table
#   - Print payslip (with company info header)
#   - Gross->Net and Net->Gross using 2025 rules you provided
#   - Company Info saved in ./PD/company_info.json (auto-created and loaded)
#   - CSV/Excel export (Excel requires openpyxl)
# ============================

# ==== CONSTANTS (2025) ====
TAX_BANDS = [
    (24000, 0.10),
    (8333, 0.25),
    (467667, 0.30),
    (float('inf'), 0.35),
]
PERSONAL_RELIEF = 2400.00
HOUSING_LEVY_RATE = 0.015
SHIF_RATE = 0.0275
SHIF_MIN = 300.0
NSSF_RATE = 0.06
NSSF_LEL = 8000.0
NSSF_UEL = 72000.0
CAP_POST_RETIRE_MEDICAL = 15000.0
CAP_MORTGAGE_INTEREST = 30000.0
CAP_REGISTERED_PENSION = 30000.0
INSURANCE_RELIEF_RATE = 0.15
INSURANCE_RELIEF_CAP = 5000.0  # per month


def fmt(x):
    try:
        return f"{float(x):,.2f}"
    except Exception:
        return str(x)


# ==== CORE CALCULATIONS ====

def calc_shif(gross):
    return max(SHIF_MIN, gross * SHIF_RATE)


def calc_nssf_employee(gross):
    """Employee NSSF: 6% of Tier I (<= 8,000) + 6% of Tier II (8,000..72,000)."""
    tier1_base = min(gross, NSSF_LEL)
    tier1 = tier1_base * NSSF_RATE
    tier2_base = max(0.0, min(gross, NSSF_UEL) - NSSF_LEL)
    tier2 = tier2_base * NSSF_RATE
    return tier1 + tier2


def calc_housing_levy(gross):
    return gross * HOUSING_LEVY_RATE


def calc_paye_before_relief(taxable):
    tax = 0.0
    remaining = taxable
    for band_width, rate in TAX_BANDS:
        if remaining <= 0:
            break
        take = min(remaining, band_width)
        tax += take * rate
        remaining -= take
    return max(0.0, tax)


def calc_reliefs(personal_relief=True, insurance_premiums=0.0):
    rel = 0.0
    if personal_relief:
        rel += PERSONAL_RELIEF
    if insurance_premiums > 0:
        rel += min(INSURANCE_RELIEF_CAP, insurance_premiums * INSURANCE_RELIEF_RATE)
    return rel


def payroll_breakdown(
    name: str,
    payroll_no: int,
    gross: float,
    other_benefits: float = 0.0,
    other_deductions: float = 0.0,
    addl_pension: float = 0.0,
    mortgage_interest: float = 0.0,
    post_ret_medical: float = 0.0,
    insurance_premiums: float = 0.0,
    apply_personal_relief: bool = True,
):
    gross_total = max(0.0, gross) + max(0.0, other_benefits)

    # Allowables (deducted from gross to get taxable)
    nssf = calc_nssf_employee(gross_total)
    shif = calc_shif(gross_total)
    housing_levy = calc_housing_levy(gross_total)

    allowable_addl_pension = min(max(0.0, addl_pension), CAP_REGISTERED_PENSION)
    allowable_mortgage = min(max(0.0, mortgage_interest), CAP_MORTGAGE_INTEREST)
    allowable_medical = min(max(0.0, post_ret_medical), CAP_POST_RETIRE_MEDICAL)

    allowable_total = nssf + shif + housing_levy + allowable_addl_pension + allowable_mortgage + allowable_medical

    taxable_pay = max(0.0, gross_total - allowable_total)
    paye_before_relief = calc_paye_before_relief(taxable_pay)
    reliefs = calc_reliefs(apply_personal_relief, max(0.0, insurance_premiums))
    paye = max(0.0, paye_before_relief - reliefs)

    total_deductions = nssf + shif + housing_levy + paye + max(0.0, other_deductions)
    net_pay = gross_total - total_deductions

    return {
        "Payroll No": payroll_no,
        "Name": name,
        "Gross": round(gross, 2),
        "Benefits": round(other_benefits, 2),
        "Gross Basis": round(gross_total, 2),
        "NSSF": round(nssf, 2),
        "SHIF": round(shif, 2),
        "Housing Levy": round(housing_levy, 2),
        "PAYE": round(paye, 2),
        "Other Deductions": round(other_deductions, 2),
        "Net": round(net_pay, 2),
        "Taxable": round(taxable_pay, 2),
        "Allowable Total": round(allowable_total, 2),
        "Reliefs": round(reliefs, 2),
    }


def net_from_gross(gross, other_benefits=0.0, other_deductions=0.0,
                   addl_pension=0.0, mortgage_interest=0.0, post_ret_medical=0.0,
                   insurance_premiums=0.0, apply_personal_relief=True):
    return payroll_breakdown("_", 0, gross, other_benefits, other_deductions,
                             addl_pension, mortgage_interest, post_ret_medical,
                             insurance_premiums, apply_personal_relief)["Net"]


def gross_from_net(target_net, other_benefits=0.0, other_deductions=0.0,
                   addl_pension=0.0, mortgage_interest=0.0, post_ret_medical=0.0,
                   insurance_premiums=0.0, apply_personal_relief=True,
                   lo=0.0, hi=5_000_000.0, iters=80, tol=0.5):
    if target_net < 0:
        return 0.0
    # Expand upper bound if needed
    while net_from_gross(hi, other_benefits, other_deductions, addl_pension,
                         mortgage_interest, post_ret_medical, insurance_premiums,
                         apply_personal_relief) < target_net:
        hi *= 2
        if hi > 100_000_000:
            break
    # Binary search
    for _ in range(iters):
        mid = (lo + hi) / 2.0
        net = net_from_gross(mid, other_benefits, other_deductions, addl_pension,
                             mortgage_interest, post_ret_medical, insurance_premiums,
                             apply_personal_relief)
        diff = net - target_net
        if abs(diff) <= tol:
            return round(mid, 2)
        if diff < 0:
            lo = mid
        else:
            hi = mid
    return round(hi, 2)


# ==== GUI ====
class PayrollApp(tk.Tk):
    COLS = ["Payroll No", "Name", "Gross", "Benefits", "Gross Basis",
            "NSSF", "SHIF", "Housing Levy", "PAYE", "Other Deductions",
            "Net", "Taxable", "Allowable Total", "Reliefs"]

    def __init__(self):
        super().__init__()
        self.title("Kenya Payroll – Multi-Employee (2025)")
        self.geometry("1280x800")
        self.employees = []
        self.next_payroll_no = 1
        self.company_info = self._load_company_info()
        self._build()

    # ---------- Company Info ----------
    def _company_info_path(self):
        folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "PD")
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, "company_info.json")

    def _load_company_info(self):
        path = self._company_info_path()
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save_company_info(self):
        path = self._company_info_path()
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.company_info, f, indent=2)
        except Exception as e:
            messagebox.showerror("Company Info", f"Failed to save: {e}")

    def edit_company_info(self):
        popup = tk.Toplevel(self)
        popup.title("Company Info")
        popup.geometry("460x320")
        labels = ["Company Name", "Address", "Contacts", "Email Address", "KRA PIN"]
        vars = {}
        for i, lbl in enumerate(labels):
            ttk.Label(popup, text=lbl).grid(row=i, column=0, sticky="w", padx=6, pady=4)
            v = tk.StringVar(value=self.company_info.get(lbl, ""))
            vars[lbl] = v
            ttk.Entry(popup, textvariable=v, width=40).grid(row=i, column=1, sticky="w", padx=6, pady=4)
        def save_and_close():
            for k, v in vars.items():
                self.company_info[k] = v.get().strip()
            self._save_company_info()
            popup.destroy()
        ttk.Button(popup, text="Save", command=save_and_close).grid(row=len(labels), column=0, columnspan=2, pady=10)

    # ---------- UI Build ----------
    def _build(self):
        # Menu (Company Info)
        menu = tk.Menu(self)
        self.config(menu=menu)
        company_menu = tk.Menu(menu, tearoff=0)
        company_menu.add_command(label="Edit Company Info", command=self.edit_company_info)
        menu.add_cascade(label="Company", menu=company_menu)

        root = ttk.Frame(self, padding=10)
        root.pack(fill="both", expand=True)

        form = ttk.LabelFrame(root, text="Employee Input")
        form.pack(fill="x", pady=6)

        def add_row(frm, r, label, var, width=24):
            ttk.Label(frm, text=label).grid(row=r, column=0, sticky="w", padx=4, pady=3)
            e = ttk.Entry(frm, textvariable=var, width=width)
            e.grid(row=r, column=1, sticky="w", padx=4, pady=3)
            return e

        self.v_payroll_no = tk.StringVar()
        self.v_name = tk.StringVar()
        self.v_gross = tk.StringVar()
        self.v_net_target = tk.StringVar()
        self.v_benefits = tk.StringVar()
        self.v_other_deds = tk.StringVar()
        self.v_pension = tk.StringVar()
        self.v_mortgage = tk.StringVar()
        self.v_medical = tk.StringVar()
        self.v_ins_prem = tk.StringVar()
        self.v_apply_relief = tk.BooleanVar(value=True)

        left = ttk.Frame(form)
        right = ttk.Frame(form)
        left.grid(row=0, column=0, padx=6, pady=6, sticky="nw")
        right.grid(row=0, column=1, padx=6, pady=6, sticky="nw")

        r = 0
        add_row(left, r, "Payroll No (auto)", self.v_payroll_no); r += 1
        add_row(left, r, "Employee Name", self.v_name, 30); r += 1
        add_row(left, r, "Gross Pay (leave blank if solving from Net)", self.v_gross); r += 1
        add_row(left, r, "Target Net Pay (leave blank if Gross provided)", self.v_net_target); r += 1
        add_row(left, r, "Other Benefits (pre-tax)", self.v_benefits); r += 1
        add_row(left, r, "Other Deductions (post-tax)", self.v_other_deds); r += 1

        r2 = 0
        add_row(right, r2, "Pension (<=30,000)", self.v_pension); r2 += 1
        add_row(right, r2, "Mortgage Interest (<=30,000)", self.v_mortgage); r2 += 1
        add_row(right, r2, "Post-Ret Medical (<=15,000)", self.v_medical); r2 += 1
        add_row(right, r2, "Insurance Premiums", self.v_ins_prem); r2 += 1
        ttk.Checkbutton(right, text="Apply Personal Relief (2,400)", variable=self.v_apply_relief)\
            .grid(row=r2, column=0, columnspan=2, sticky="w", padx=4, pady=3)

        btns = ttk.Frame(root)
        btns.pack(fill="x", pady=6)
        ttk.Button(btns, text="Add Employee", command=self.add_employee).pack(side="left")
        ttk.Button(btns, text="Remove Selected", command=self.remove_selected).pack(side="left", padx=6)
        ttk.Button(btns, text="Clear Form", command=self.clear_form).pack(side="left", padx=6)
        ttk.Button(btns, text="Edit Payroll No", command=self.edit_payroll_no).pack(side="left", padx=6)
        ttk.Button(btns, text="Print Payslip", command=self.print_payslip).pack(side="right", padx=6)
        ttk.Button(btns, text="Export CSV", command=self.export_csv).pack(side="right", padx=6)
        ttk.Button(btns, text="Export Excel", command=self.export_excel).pack(side="right", padx=6)

        # Table + Always-visible scrollbars
        tbl_frame = ttk.Frame(root)
        tbl_frame.pack(fill="both", expand=True)

        xscroll = tk.Scrollbar(tbl_frame, orient="horizontal")
        yscroll = tk.Scrollbar(tbl_frame, orient="vertical")
        self.tree = ttk.Treeview(tbl_frame, columns=self.COLS, show="headings",
                                 xscrollcommand=xscroll.set, yscrollcommand=yscroll.set)
        for col in self.COLS:
            self.tree.heading(col, text=col)
            anchor = "e"; width = 120
            if col == "Payroll No":
                anchor = "center"; width = 110
            if col == "Name":
                anchor = "w"; width = 220
            self.tree.column(col, width=width, anchor=anchor)
        self.tree.grid(row=0, column=0, sticky="nsew")

        xscroll.config(command=self.tree.xview)
        yscroll.config(command=self.tree.yview)
        xscroll.grid(row=1, column=0, sticky="ew")
        yscroll.grid(row=0, column=1, sticky="ns")
        tbl_frame.grid_rowconfigure(0, weight=1)
        tbl_frame.grid_columnconfigure(0, weight=1)

        # Footer note
        note = (
            "2025 rules: NSSF 6% Tier I (<=8,000) + Tier II (8,000..72,000); "
            "SHIF 2.75% of gross (min 300, no cap); Housing Levy 1.5% of gross. "
            "Allowables reduce Taxable (NSSF, SHIF, Housing Levy, Pension<=30k, Mortgage<=30k, Post-Ret Medical<=15k). "
            "PAYE bands 10%/25%/30%/35% with Personal Relief 2,400 and Insurance Relief 15% up to 5,000."
        )
        ttk.Label(root, text=note, foreground="#555").pack(fill="x", pady=4)

    # ---------- Helpers ----------
    def _pf(self, s):
        try:
            v = float(str(s).strip().replace(",", ""))
            return v if v >= 0 else 0.0
        except Exception:
            return 0.0

    def _get_selected_index(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return self.tree.index(sel[0])

    def clear_form(self):
        for v in [self.v_payroll_no, self.v_name, self.v_gross, self.v_net_target, self.v_benefits, self.v_other_deds,
                  self.v_pension, self.v_mortgage, self.v_medical, self.v_ins_prem]:
            v.set("")
        self.v_apply_relief.set(True)

    # ---------- Actions ----------
    def add_employee(self):
        # Payroll No handling
        payroll_no_str = self.v_payroll_no.get().strip()
        if payroll_no_str:
            try:
                payroll_no = int(payroll_no_str)
            except Exception:
                messagebox.showerror("Payroll No", "Invalid payroll number.")
                return
            # Ask confirmation if user overrides auto-increment
            if not messagebox.askyesno("Confirm Payroll No",
                                       f"Use Payroll No {payroll_no}? This overrides auto-increment."):
                return
            # Prevent duplicates
            if any(emp["Payroll No"] == payroll_no for emp in self.employees):
                messagebox.showerror("Payroll No", "Duplicate payroll number.")
                return
        else:
            payroll_no = self.next_payroll_no
            self.next_payroll_no += 1

        name = self.v_name.get().strip() or "Employee"
        gross_in = self._pf(self.v_gross.get())
        net_target = self._pf(self.v_net_target.get())
        benefits = self._pf(self.v_benefits.get())
        other_deds = self._pf(self.v_other_deds.get())
        pension = self._pf(self.v_pension.get())
        mortgage = self._pf(self.v_mortgage.get())
        medical = self._pf(self.v_medical.get())
        ins_prem = self._pf(self.v_ins_prem.get())
        apply_relief = bool(self.v_apply_relief.get())

        if gross_in > 0 and net_target > 0:
            messagebox.showerror("Input", "Enter either Gross OR Target Net, not both.")
            return
        if gross_in <= 0 and net_target <= 0:
            messagebox.showerror("Input", "Provide Gross Pay or Target Net Pay.")
            return

        if gross_in <= 0 and net_target > 0:
            gross_in = gross_from_net(
                net_target, benefits, other_deds, pension, mortgage, medical, ins_prem, apply_relief
            )

        row = payroll_breakdown(
            name, payroll_no, gross_in, benefits, other_deds,
            pension, mortgage, medical, ins_prem, apply_relief
        )
        self.employees.append(row)
        self._insert_row(row)
        self.clear_form()

    def _insert_row(self, row):
        values = []
        for col in self.COLS:
            if col in ("Payroll No", "Name"):
                values.append(row[col])
            else:
                values.append(fmt(row[col]))
        self.tree.insert("", tk.END, values=values)

    def remove_selected(self):
        idx = self._get_selected_index()
        if idx is None:
            return
        self.tree.delete(self.tree.get_children()[idx])
        if 0 <= idx < len(self.employees):
            del self.employees[idx]

    def edit_payroll_no(self):
        idx = self._get_selected_index()
        if idx is None:
            messagebox.showinfo("Edit Payroll No", "Select a row first.")
            return
        emp = self.employees[idx]
        current_no = emp["Payroll No"]
        new_no = simpledialog.askinteger("Edit Payroll No",
                                         f"Current: {current_no}\nEnter new Payroll No:",
                                         minvalue=1)
        if new_no is None:
            return
        if new_no == current_no:
            return
        if any(e["Payroll No"] == new_no for e in self.employees if e is not emp):
            messagebox.showerror("Payroll No", "That payroll number already exists.")
            return
        if not messagebox.askyesno("Confirm Change",
                                   f"Change Payroll No from {current_no} to {new_no}?"):
            return
        # Apply change
        emp["Payroll No"] = new_no
        # Update table row
        item_id = self.tree.get_children()[idx]
        values = list(self.tree.item(item_id, "values"))
        values[0] = new_no  # first column is Payroll No
        self.tree.item(item_id, values=values)

    def export_csv(self):
        if not self.employees:
            messagebox.showinfo("Export", "No data to export.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")])
        if not path:
            return
        cols = [
            "Payroll No","Name","Gross","Benefits","Gross Basis","NSSF","SHIF","Housing Levy",
            "PAYE","Other Deductions","Net","Taxable","Allowable Total","Reliefs"
        ]
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=cols)
                writer.writeheader()
                for row in self.employees:
                    writer.writerow({k: row.get(k) for k in cols})
            messagebox.showinfo("Export", f"Saved: {path}")
        except Exception as e:
            messagebox.showerror("Export", str(e))

    def export_excel(self):
        if not self.employees:
            messagebox.showinfo("Export", "No data to export.")
            return
        try:
            import openpyxl
            from openpyxl import Workbook
        except Exception:
            messagebox.showerror("Export Excel", "openpyxl is not installed. Use Export CSV or install 'openpyxl'.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Workbook", "*.xlsx")])
        if not path:
            return
        cols = [
            "Payroll No","Name","Gross","Benefits","Gross Basis","NSSF","SHIF","Housing Levy",
            "PAYE","Other Deductions","Net","Taxable","Allowable Total","Reliefs"
        ]
        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "Payroll"
            ws.append(cols)
            for row in self.employees:
                ws.append([row.get(c) for c in cols])
            # width
            for i, c in enumerate(cols, start=1):
                ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = max(12, len(c) + 2)
            wb.save(path)
            messagebox.showinfo("Export", f"Saved: {path}")
        except Exception as e:
            messagebox.showerror("Export", str(e))

    def print_payslip(self):
        idx = self._get_selected_index()
        if idx is None:
            messagebox.showinfo("Payslip", "Select an employee row first.")
            return
        emp = self.employees[idx]
        html = self._payslip_html(emp)
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".html")
        with open(tmp.name, "w", encoding="utf-8") as f:
            f.write(html)
        webbrowser.open('file://' + os.path.realpath(tmp.name))

    def _payslip_html(self, emp):
        # Build company header
        header_lines = []
        name_line = self.company_info.get("Company Name", "").strip()
        address_line = self.company_info.get("Address", "").strip()
        contacts_line = self.company_info.get("Contacts", "").strip()
        email_line = self.company_info.get("Email Address", "").strip()
        kra_pin = self.company_info.get("KRA PIN", "").strip()

        if name_line:
            header_lines.append(f"<div class='cname'>{name_line}</div>")
        if address_line:
            header_lines.append(f"<div>{address_line}</div>")
        contact_bits = []
        if contacts_line:
            contact_bits.append(contacts_line)
        if email_line:
            contact_bits.append(email_line)
        if contact_bits:
            header_lines.append("<div>" + " | ".join(contact_bits) + "</div>")
        if kra_pin:
            header_lines.append(f"<div>KRA PIN: {kra_pin}</div>")

        header_html = "<br>".join(header_lines) if header_lines else ""

        rows = [
            ("Payroll No", emp["Payroll No"]),
            ("Name", emp["Name"]),
            ("Gross", fmt(emp["Gross"])),
            ("Benefits", fmt(emp["Benefits"])),
            ("Gross Basis", fmt(emp["Gross Basis"])),
            ("NSSF", fmt(emp["NSSF"])),
            ("SHIF", fmt(emp["SHIF"])),
            ("Housing Levy", fmt(emp["Housing Levy"])),
            ("PAYE", fmt(emp["PAYE"])),
            ("Other Deductions", fmt(emp["Other Deductions"])),
            ("Taxable", fmt(emp["Taxable"])),
            ("Allowable Total", fmt(emp["Allowable Total"])),
            ("Reliefs", fmt(emp["Reliefs"])),
            ("Net Pay", fmt(emp["Net"])),
        ]
        trs = "\n".join(f"<tr><th class='lbl'>{k}</th><td>{v}</td></tr>" for k, v in rows)

        return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>Payslip</title>
<style>
body{{font-family:Arial,Helvetica,sans-serif;padding:24px}}
h1{{margin:8px 0 10px 0}}
.header .cname{{font-size:18px;font-weight:700}}
table{{border-collapse:collapse;min-width:450px;margin-top:12px}}
td,th{{border:1px solid #ccc;padding:6px 8px;text-align:right}}
th.lbl{{text-align:left;background:#f7f7f7;width:50%}}
.footer{{margin-top:10px;color:#666;font-size:12px}}
hr{{margin:10px 0 10px 0}}
@media print{{body{{padding:0}}}}
</style>
</head><body>
<div class="header">
{header_html}
</div>
<hr>
<h1>Payslip</h1>
<table>
<tbody>
{trs}
</tbody>
</table>
<p class="footer">Generated by Kenya Payroll App (2025 rules).</p>
</body></html>"""

if __name__ == "__main__":
    app = PayrollApp()
    app.mainloop()
